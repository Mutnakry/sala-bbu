<?php

// include "./functions.php";
// $result = array("succes" => 0, "error" => 0);
// if (isset($_POST["UserLoginName"]) && isset($_POST['PasswordLogin'])) {
//      $username = $_POST['UserLoginName'];
//     $password = $_POST['PasswordLogin'];
//     $func = new functions();
//     $login = $funs->login_user($username, $password);
//     if ($login != false) {
//         $result['succes'];
//         $result["msg_success"] = "login successed.";
//         $result["uderid "] = $login['UserID'];
//         $result["userName"] = $login['UserName'];
//         $result["userPass"] = $login['UserPass'];
//         $result["userType"] = $login['userType'];
//         $result["userImage"] = $login['userImage'];
//         $result["userEmail"] = $login['userEmail'];
//         $result["fullname"] = $login['fullname'];
//         $result["phone"] = $login['phone'];
//         print json_encode($result);
//     } else {
//         $result['succes'];
//         $result["msg_success"] = "Failed to login  the user.";
    
//         print json_encode($result);
//     }
// } else {
//     $result["error"] = 1;
//     $result["msg_error"] = "Accuess denird...";
//     print json_encode(($result));
// }







// include "./functions.php";

// $result = array("success" => 0, "error" => 0);

// if (isset($_POST["UserLoginName"]) && isset($_POST['PasswordLogin'])) {
//     $username = $_POST['UserLoginName'];
//     $password = $_POST['PasswordLogin'];

//     $func = new functions();
//     $login = $func->login_user($username, $password);

//     if ($login != false) {
//         $result['success'] = 1;
//         $result["msg_success"] = "Login successful.";
//         $result["userID"] = $login['UserID'];   
//         $result["userName"] = $login['userName'];
//         $result["userType"] = $login['userType'];
//         $result["userImage"] = $login['userImage'];
//         $result["userEmail"] = $login['userEmail'];
//         $result["fullname"] = $login['fullname'];
//         $result["phone"] = $login['phone'];
//     } else {
//         $result['error'] = 1;
//         $result["msg_error"] = "Failed to log in. Invalid username or password.";
//     }
// } else {
//     $result["error"] = 1;
//     $result["msg_error"] = "Access denied: Missing parameters.";
// }

// header('Content-Type: application/json');
// echo json_encode($result);
?>


<?php
include './functions.php';

$result = array("success" => 0, "error" => 0);

// Check if the required fields are set
if (isset($_POST['UserLoginName']) && isset($_POST['PasswordLogin'])) {
    $username = $_POST['UserLoginName']; // Username
    $password = $_POST['PasswordLogin']; // Password

    $func = new functions();
    $login = $func->login_user($username, $password);

    if ($login != false) {
        // Login successful
        $result['success'] = 1;
        $result["msg_success"] = "Login successful.";
        $result["userID"] = $login['userID'];
        $result["userName"] = $login['userName'];
        $result["userType"] = $login['userType'];
        $result["userImage"] = $login['userImage'];
        $result["userEmail"] = $login['userEmail'];
        $result["fullname"] = $login['fullname'];
        $result["phone"] = $login['phone'];
    } else {
        // Login failed
        $result['error'] = 1;
        $result["msg_error"] = "Failed to log in. Invalid username or password.";
    }
} else {
    $result["error"] = 1;
    $result["msg_error"] = "Access denied: Missing parameters.";
}

header('Content-Type: application/json');
echo json_encode($result);
?>
