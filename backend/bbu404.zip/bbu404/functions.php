<?php
// class functions
// {
//    /// data member or menber variable
//    private $db;
//    private $sql;
//    private $result;
//    // contractor
//    function __construct()
//    {
//     require_once 'connection.php';
//     /// creating an instance of class db
//     $this->db=new DBconnection();
//     /// calling the methed
//     $this->db->connect();

//    }
//    //desctructor
//    function __destruct()
//    {
//     $this->db->connect()->close();
//    }
//    //methord

//    public function insert_data($tablename,$fields,$values){
//     // count fields in array
//     $count = count($fields);
//     /// generate insert statement
//     $this->sql ="INSERT INTO $tablename(";
//     for($i=0; $i < $count; $i++){
//         $this->sql .=$fields[$i];
//         if($i < $count -1){
//             $this->sql .= ",";
//         }
//         else{
//             $this->sql .= ") VALUES (";
//         }
//     }
//     for($i=0;$i<$count;$i++){
//         $this->sql .= "'".$values[$i]."'";
//         if($i < $count -1){
//             $this->sql .= ",";
//         }
//         else{
//             $this->sql .= ")";
//         }
//     }

//     return  $this->sql;
//     // execute  insert statement

//     $this->result=$this->db->connect()->query($this->sql);
//     if($this->result === true){
//         return true;
//     }
//     else{
//         return false;
//     }

//    }

// }

class functions
{
    private $db;
    private $sql;
    private $result;

    function __construct()
    {
        // Include the DB connection file
        require_once 'connection.php';
        // Create an instance of the DBconnection class
        $this->db = new DBconnection();
    }

    function __destruct()
    {
        // Close the connection when the object is destroyed
        $this->db->connect()->close();
    }

    public function insert_data($tablename, $fields, $values)
    {
        // Count the fields
        $count = count($fields);

        // Start the INSERT SQL query
        $this->sql = "INSERT INTO $tablename (";

        // Add field names to the query
        for ($i = 0; $i < $count; $i++) {
            $this->sql .= $fields[$i];
            if ($i < $count - 1) {
                $this->sql .= ", ";
            } else {
                $this->sql .= ") VALUES (";
            }
        }

        // Add corresponding values to the query
        for ($i = 0; $i < $count; $i++) {
            $this->sql .= "'" . $values[$i] . "'";
            if ($i < $count - 1) {
                $this->sql .= ", ";
            } else {
                $this->sql .= ")";
            }
        }

        // Execute the query
        $conn = $this->db->connect(); // Get the database connection
        $this->result = $conn->query($this->sql);

        // Check if the query was successful
        if ($this->result === true) {
            return true; // Insert successful
        } else {
            return false; // Insert failed
        }
    }

    public function login_user($username, $userpass)
    {
        $user = stripslashes($username);
        $pwd = stripslashes($userpass);
        $user = $this->db->connect()->real_escape_string($user);
        $pwd = $this->db->connect()->real_escape_string($pwd);

        // MD5 is insecure. Use password_hash() and password_verify() instead.
        $md5 = md5($pwd);

        $this->sql = "SELECT * FROM tbluser WHERE userName='$user' AND userPass='$md5'";
        $this->result = $this->db->connect()->query($this->sql);

        if (mysqli_num_rows($this->result) == 1) {
            return mysqli_fetch_assoc($this->result);
        } else {
            return false;
        }
    }

    public function change_password($userID, $currentPassword, $newPassword)
    {
        // Get the database connection
        $conn = $this->db->connect();

        // Fetch the current password hash from the database
        $stmt = $conn->prepare("SELECT userPass FROM users WHERE UserID = ?");
        $stmt->bind_param("i", $userID);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
        $stmt->close();

        // Verify the current password using bcrypt (using password_verify)
        if ($user && password_verify($currentPassword, $user['userPass'])) {
            // Hash the new password using bcrypt
            $newPasswordHash = md5($newPassword);

            // Update the password in the database
            $stmt = $conn->prepare("UPDATE users SET userPass = ? WHERE UserID = ?");
            $stmt->bind_param("si", $newPasswordHash, $userID);
            if ($stmt->execute()) {
                $stmt->close();
                return true; // Password changed successfully
            }
            $stmt->close();
        }

        return false; // Password verification failed or update failed
    }


    public function update_data($tablename, $fields, $values,$fid,$vid)
    {
        $count = count($fields);
        // gernerate update statement
        // syntax update table set col1=val1 ,col2=val2,... where condition
        $this ->sql = "UPDATE $tablename SET";
        for($i=0;$i<$count;$i++){
            $this->sql+$fields[$i]. "='" .$values[$i]. "'";
            if($i <$count - 1 ){
                $this->sql .= ",";
            }
            else{
                $this->sql .= " WHERE $fid='$vid';";
            }
        }
        $this->result = $this->db->connect()()->query($this->sql);
        if($this->result === true)
        {
            return true;
        }
        else{
            return false;
        }
        
        //excecutr update statemrnty
    }
}
