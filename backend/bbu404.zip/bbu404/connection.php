<?php
// $server = "localhost";
// $username = "root";
// $password = "";
// $database = "mobile_bmc404db";
// $conn = mysqli_connect("$server", "$username", "$password");
// $select_db = mysqli_select_db($conn, $database);
// if (!$select_db) {
//     echo ("connection terminated");
// }
?>

<?php
// class DBconnection
// {
//     private $server = "localhost";
//     private $username = "root";
//     private $password = "";
//     private $database = "mobile_bmc404db";

//     public function connect()
//     {
//         try {
//             $conn = new mysqli(
//                 $this->server,
//                 $this->username,
//                 $this->password,
//                 $this->database,

//             );
//             return $conn;
//         } catch (\Exception $ex) {
//             echo "Error:" . $ex->getMessage();
//         }
//     }
// }

class DBconnection
{
    private $server = "localhost";
    private $username = "root";
    private $password = "";
    private $database = "mobile_bmc404db";

    public function connect()
    {
        // Create a connection
        $conn = new mysqli($this->server, $this->username, $this->password, $this->database);

        // Check if the connection was successful
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        return $conn;
    }
}

?>