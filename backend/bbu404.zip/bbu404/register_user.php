<?php
include './functions.php';

$result = array("success" => 0, "error" => 0);

// Debug incoming dat
if (isset($_POST['fullname']) && isset($_POST['userName']) && isset($_POST['userPass'])) {
    $fullname = $_POST['fullname']; // Match 'fullname' key
    $username = $_POST['userName'];
    $userpass = md5($_POST['userPass']); // Secure password hashing

    $fields = array('userName', 'userPass', 'fullname'); // Adjusted for corrected column names
    $values = array($username, $userpass, $fullname);

    $func = new functions();
    $insert = $func->insert_data('tbluser', $fields, $values);

    if ($insert == true) {
        $result["success"] = 1;
        $result["msg_success"] = "User registered successfully";
    } else {
        $result["error"] = 2;
        $result["msg_error"] = "Failed to register user";
    }
} else {
    $result["error"] = 1;
    $result["msg_error"] = "Access Denied: Missing parameters";
}

print json_encode($result);
?>



<?php
// include './functions.php';

// $result = array("success" => 0, "error" => 0);

// // Check if the required fields are set
// if (isset($_POST['fullname']) && isset($_POST['userName']) && isset($_POST['userPass'])) {
//     $fullname = $_POST['fullname']; // Full name
//     $username = $_POST['userName']; // Username
//     $userpass = $_POST['userPass']; // Password

//     // Hash the password
//     $hashedPassword = password_hash($userpass, PASSWORD_DEFAULT); // Hashing password with bcrypt

//     $fields = array('userName', 'userPass', 'fullname');
//     $values = array($username, $hashedPassword, $fullname); // Store the hashed password

//     // Call the insert_data function
//     $func = new functions();
//     $insert = $func->insert_data('tbluser', $fields, $values);

//     if ($insert == true) {
//         $result["success"] = 1;
//         $result["msg_success"] = "User registered successfully";
//     } else {
//         $result["error"] = 2;
//         $result["msg_error"] = "Failed to register user";
//     }
// } else {
//     $result["error"] = 1;
//     $result["msg_error"] = "Access Denied: Missing parameters";
// }

// header('Content-Type: application/json');
// echo json_encode($result);
?>
