<?php
// // Include the functions class
// require_once 'functions.php';

// $result = array("success" => 0, "error" => 0);

// if (isset($_POST['userID']) && isset($_POST['userPassword'])) {
//     $userID = $_POST['userID'];
//     $userPassword = md5($_POST['userPassword']);
//     $field = array("k");
//     $value = array($userPassword);

//     $func = new functions();
//     $update = $func->update_data('tbluser',$field,$value,'userID',$id);
//     if ($update == true) {
//         $result['success'] = 1;
//         $result['msg'] = "Password changed successfully.";
//         echo json_encode($result);
//     } else {
//         $result['error'] = 1;
//         $result['msg'] = "Failed to change the password. Current password is incorrect or update failed.";
//     }
// } else {
//     $result['error'] = 1;
//     $result['msg'] = "Invalid request. Missing required parameters.";
//     echo json_encode($result);
// }

// // Return JSON response
// header('Content-Type: application/json');
// echo json_encode($result);
?> 



<?php
// Include the functions class
require_once 'functions.php';

// Prepare a response array
$result = ["success" => 0, "error" => 0];

// Check if required parameters are provided
if (isset($_POST['userID']) && isset($_POST['userPassword'])) {
    $userID = htmlspecialchars($_POST['userID']);
    $userPassword = htmlspecialchars($_POST['userPassword']);

    // Hash the password using bcrypt
    $hashedPassword = password_hash($userPassword, PASSWORD_BCRYPT);

    // Fields to update
    $fields = ["userPass"];
    $values = [$hashedPassword];

    // Create an instance of the functions class
    $func = new functions();

    // Call update_data to update the userPass
    $update = $func->update_data('tbluser', $fields, $values, 'userID', $userID);

    if ($update === true) {
        $result['success'] = 1;
        $result['msg'] = "Password changed successfully.";
    } else {
        $result['error'] = 1;
        $result['msg'] = "Failed to change the password.";
    }
} else {
    $result['error'] = 1;
    $result['msg'] = "Invalid request. Missing required parameters.";
}

// Return JSON response
header('Content-Type: application/json');
echo json_encode($result);
